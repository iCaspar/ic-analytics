# iCaspar Analytics

### A minimalist WordPress plugin to include Google Analytics on a website.

Add the Google Analytics website tracking script to a WordPress website.

The tracking script is added to all front facing pages when the user is not logged in as an administrator.

Just enter your analytics tracking ID (UA-XXXXXXX-YY) in the customizer Site Identity panel and you're good to go.